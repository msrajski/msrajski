<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>McKenzie Rajski's Bio</title>
</head>

<body>
<table width="1000" border="0" align="center">
  <tbody>
    <tr>
      <td height="95" colspan="8" align="center"><h1>&nbsp;<span style="font-family: Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', serif">Welcome to McKenzie Rajski's Page</span></h1></td>
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
      <td width="312" rowspan="6" align="center"><img src="MCKENZIE.jpg" width="250" height="344" alt=""></td>
      <td colspan="5">&nbsp;</td>
    </tr>
    <tr>
      <td width="1">&nbsp;</td>
      <td width="1">&nbsp;</td>
      <td colspan="5" align="center" style="font-family: Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', serif"><h3>About Me</h3></td>
    </tr>
    <tr>
      <td height="108" rowspan="4">&nbsp;</td>
      <td rowspan="4">&nbsp;</td>
      <td height="109" colspan="2">Hello! My Name is McKenzie Rajski and I am a senior at Ball State University. I am majoring in marketing and minoring in digital media. I am from Noblesville, Indiana and plan on moving further out of Indiana after college to pursue a career in UX Research. </td>
      <td colspan="3" rowspan="4">&nbsp;</td>
    </tr>
    <tr>
      <td height="17" colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td height="17" colspan="2" align="center" style="font-family: Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', serif"><h3>Links</h3></td>
    </tr>
    <tr>
      <td width="337" height="50" align="center"><a href="https://www.linkedin.com/in/mckenzie-rajski-71731819b/" target="new">My LinkedIn Page</a></td>
      <td width="309" align="center"><a href="https://www.bsu.edu/academics/collegesanddepartments/mcob" target="new">Ball State Miller College of Business</a></td>
    </tr>
    <tr>
      <td height="56" colspan="8">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="8" align="center"><h2 style="font-family: Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', serif">My Education</h2></td>
    </tr>
    <tr>
      <td colspan="8">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="3" align="center"><h3 style="font-family: Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', serif"><a href="https://www.noblesvilleschools.org/domain/8" target="new">High School: Noblesville High School</a></h3></td>
      <td>&nbsp;</td>
      <td colspan="4" align="center"><h3 style="font-family: Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', serif"><a href="https://www.bsu.edu/" target="new">College: Ball State University</a></h3></td>
    </tr>
    <tr>
      <td rowspan="3">&nbsp;</td>
      <td rowspan="3">&nbsp;</td>
      <td rowspan="2" align="center" valign="top"><img src="https://github.com/msrajski/msrajski/pull/2#issue-1083701620" width="300" height="300" alt=""/></td>
      <td height="221" align="center">&nbsp;</td>
      <td rowspan="2" align="center" valign="top"><img src="https://github.com/msrajski/msrajski/blob/main/ballstateuniversity.jpg" width="300" height="300" alt=""/></td>
      <td colspan="3" rowspan="3">&nbsp;</td>
    </tr>
    <tr>
      <td height="45" align="center"><h3>Completed College Courses</h3></td>
    </tr>
    <tr>
      <td align="left" valign="top"><ul>
        <li>Introduction to Art</li>
      </ul>
        <ul>
          <li>Introduction to Psychological Science</li>
        </ul>
        <ul>
          <li>Fundamentals of Public Communication</li>
        </ul>
        <ul>
          <li>Pre-Calculus</li>
        </ul>
        <ul>
          <li>Planet Earth Geology Environment</li>
        </ul>
        <ul>
          <li>Micro Apps for Business</li>
        </ul>
        <ul>
          <li>Composing Research</li>
        </ul>
        <ul>
          <li>Elementary Mircoeconomics</li>
        </ul>
        <ul>
          <li>Elementary Macroeconomics</li>
        </ul>
        <ul>
          <li>Principles of Accounting 1</li>
        </ul>
        <ul>
          <li>Business Information Systems</li>
        </ul>
        <ul>
          <li>The Entertainment Media</li>
        </ul>
        <ul>
          <li>Principles of Accounting 2</li>
        </ul>
        <ul>
          <li>Principles of Marketing</li>
      </ul></td>
      <td height="532" valign="top"><ul>
        <li>Foundation of Business Communication</li>
      </ul>
        <ul>
          <li>Managing Behavior in Organization</li>
        </ul>
        <ul>
          <li>Principles of Business Law</li>
        </ul>
        <ul>
          <li>Principles of Finance</li>
        </ul>
        <ul>
          <li>International Marketing</li>
        </ul>
        <ul>
          <li>Professional Selling</li>
        </ul>
        <ul>
          <li>Consumer Behavior</li>
        </ul>
        <ul>
          <li>Digital World</li>
        </ul>
        <ul>
          <li>Operation Management</li>
        </ul>
        <ul>
          <li>Graphics: Computer Apps</li>
        </ul>
        <ul>
          <li>Marketing Research/Analytics</li>
        </ul>
        <ul>
          <li>Retail Strategy</li>
        </ul>
        <ul>
          <li>Usability</li>
        </ul>
        <ul>
          <li>The West in the World</li>
        </ul>
      </td>
      <td align="left" valign="top"><ul>
        <li>Principles of Finance</li>
      </ul>
        <ul>
          <li>Brief Calculus</li>
        </ul>
        <ul>
          <li>Interactivity Design</li>
        </ul>
        <ul>
          <li>Social Media Markeing</li>
        </ul>
        <ul>
          <li>Marketing Strategy</li>
        </ul>
        <ul>
          <li>Intro to Photo Storytelling</li>
        </ul>
        <ul>
          <li>Web Design</li>
        </ul>
        <ul>
          <li>Product Management</li>
        </ul>
        <ul>
          <li>Design Thinking</li>
        </ul>
        <ul>
          <li>Executing Social Media Marketing</li>
        </ul>
        <ul>
          <li>Business Policy and Strategic Management</li>
      </ul></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td colspan="2">&nbsp;</td>
      <td width="1">&nbsp;</td>
      <td width="1">&nbsp;</td>
      <td width="4">&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><h4 style="font-family: Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', serif">Skills</h4></td>
      <td colspan="2">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><li>Adobe Photoshop</li>
        <li>Adobe Dreamweaver</li>
        <li>Online Marketing</li>
        &nbsp;</td>
      <td><li>Photography</li>
        <li>Wireframing</li>
        <li>Leadership/ Management</li>
        &nbsp;</td>
      <td><li>Information Architecture</li>
        <li>Visual Communication</li>
        <li>Prototyping</li>
        &nbsp;</td>
      <td colspan="3">&nbsp;</td>
    </tr>
    <tr>
      <td height="58">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td colspan="2" align="center">&nbsp;</td>
      <td colspan="3">&nbsp;</td>
    </tr>
    <tr>
      <td height="8" colspan="8" align="center"><h4>&nbsp;</h4></td>
    </tr>
    <tr>
      <td height="9" colspan="8" align="center"><ul>
      </ul></td>
    </tr>
    <tr>
      <td height="23" colspan="8" align="center">&nbsp;</td>
    </tr>
    <tr>
      <td height="11" colspan="8" align="center"><h3>Contact Info</h3></td>
    </tr>
    <tr>
    </tr>
    <tr>
      <td height="67" colspan="3" rowspan="2" align="center"></td>
      <td height="44" align="center">Click <a href="mailto:msrajski@bsu.edu" target="new">HERE</a> to email me</td>
      <td colspan="4" rowspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td align="center"><p><a href="https://www.mckenziesiera.com" target="new">My Portfolio</a></p></td>
    </tr>
  </tbody>
</table>
</body>
</html>
